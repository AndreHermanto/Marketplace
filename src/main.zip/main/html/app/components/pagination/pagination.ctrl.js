'use strict';

angular.module('marketplace.pagination', ['ngRoute'])

.controller('PaginationCtrl',['$http','$scope', '$window', 'loginService', 'bootbox', function($http,$scope, $window, loginService, bootbox) {
}]);