package test;

public class Testing {

	public static boolean flag = false;

}
